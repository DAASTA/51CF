#include "ai.h"
#include "definition.h"
#include "user_toolbox.h"
#include <iostream>
#include <vector>
#include <time.h>
#include <stdlib.h>

void player_ai(Info& info)
{
	srand(time(0) * (int(info.towerInfo[info.myID].resource)*info.towerInfo[info.myID + 1].resource) + info.myID); //�Ҵ��ֻΪ���
	for (int i = 0; i != info.myMaxControl; ++i)
	{
		Command C;
		C.type = static_cast<CommandType>(rand() % 4);
		switch (C.type)
		{
		case addLine:
			info.myCommandList.addCommand(addLine, rand() % info.towerNum, rand() % info.towerNum);
			break;
		case cutLine:
			info.myCommandList.addCommand(addLine, rand() % info.towerNum, rand() % info.towerNum, rand() % 50);
			break;
		case changeStrategy:
			info.myCommandList.addCommand(changeStrategy, rand() % info.towerNum, rand() % 4);
			break;
		case upgrade:
			info.myCommandList.addCommand(upgrade, rand() % 4);
			break;
		default:
			break;
		}
	}
}
